'use client'

import { useState } from 'react'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FloatingChatButton } from '@/components/floating-chat-button'
import { Mail, Phone, MapPin } from 'lucide-react'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    // In a real app, you would send this to a backend
    console.log('Form submitted:', formData)
    setSubmitted(true)
    setFormData({ name: '', email: '', phone: '', message: '' })
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-8">Liên Hệ Với Chúng Tôi</h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-2xl font-bold text-primary mb-6">Thông Tin Liên Hệ</h2>

              <div className="space-y-6 mb-8">
                <div className="flex items-start gap-4">
                  <Mail size={24} className="text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg text-primary">Email</h3>
                    <a href="mailto:info@trolysonggxanh.vn" className="text-gray-700 hover:text-primary transition-colors">
                      info@trolysonggxanh.vn
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone size={24} className="text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg text-primary">Điện Thoại</h3>
                    <a href="tel:+84123456789" className="text-gray-700 hover:text-primary transition-colors">
                      +84 (123) 456-789
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <MapPin size={24} className="text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-lg text-primary">Địa Chỉ</h3>
                    <p className="text-gray-700">
                      123 Đường Xanh<br />
                      Thành phố Hồ Chí Minh<br />
                      Việt Nam 70000
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-secondary rounded-lg p-6">
                <h3 className="font-bold text-lg text-primary mb-3">Giờ Làm Việc</h3>
                <div className="space-y-2 text-gray-700 text-sm">
                  <div className="flex justify-between">
                    <span>Thứ Hai - Thứ Sáu</span>
                    <span>08:00 - 17:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Thứ Bảy</span>
                    <span>09:00 - 13:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Chủ Nhật</span>
                    <span>Đóng cửa</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold text-primary mb-6">Gửi Tin Nhắn</h2>

              {submitted && (
                <div className="mb-6 p-4 bg-green-100 border-l-4 border-green-500 text-green-700 rounded">
                  ✓ Cảm ơn bạn! Chúng tôi sẽ liên hệ lại với bạn sớm nhất.
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                    Tên Của Bạn
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-primary focus:outline-none transition-colors"
                    placeholder="Nhập tên của bạn"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-primary focus:outline-none transition-colors"
                    placeholder="Nhập email của bạn"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">
                    Điện Thoại (Tùy Chọn)
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-primary focus:outline-none transition-colors"
                    placeholder="Nhập số điện thoại của bạn"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                    Tin Nhắn
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-primary focus:outline-none transition-colors resize-none"
                    placeholder="Nhập tin nhắn của bạn..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-accent transition-colors"
                >
                  Gửi Tin Nhắn
                </button>
              </form>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingChatButton />
    </div>
  )
}

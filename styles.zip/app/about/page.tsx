import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FloatingChatButton } from '@/components/floating-chat-button'

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-8">Giới Thiệu</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-2xl font-bold text-primary mb-4">Tầm Quan Trọng Của Môi Trường</h2>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Môi trường là nền tảng của sự sống. Nó cung cấp không khí sạch để chúng ta thở, nước sạch để uống, đất đai肥沃để trồng cây, và các tài nguyên thiên nhiên cần thiết cho sự tồn tại của chúng ta.
              </p>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Một môi trường lành mạnh không chỉ là yêu cầu của sự sống mà còn là nền tảng cho sự phát triển bền vững và thịnh vượng kinh tế.
              </p>
            </div>
            <div className="bg-gradient-to-br from-green-100 to-blue-100 rounded-lg p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="text-7xl mb-4">🌱</div>
                <p className="text-xl font-semibold text-primary">Sự sống bắt đầu từ đây</p>
              </div>
            </div>
          </div>

          <div className="bg-white border-l-4 border-primary p-8 mb-16 rounded">
            <h2 className="text-2xl font-bold text-primary mb-4">Sứ Mệnh Của Chúng Tôi</h2>
            <p className="text-gray-700 leading-relaxed">
              "Trợ Lý Sống Xanh" được thành lập với mục đích giáo dục và hỗ trợ mọi người trong việc áp dụng các thực tiễn bền vững vào cuộc sống hàng ngày. Chúng tôi tin rằng bằng cách thay đổi hành vi cá nhân, chúng ta có thể tạo ra một tác động tích cực trên toàn cầu.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-secondary rounded-lg p-6">
              <div className="text-4xl mb-3">📖</div>
              <h3 className="text-xl font-bold text-primary mb-2">Giáo Dục</h3>
              <p className="text-gray-700 text-sm">
                Cung cấp kiến thức về các vấn đề môi trường và giải pháp bền vững.
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-6">
              <div className="text-4xl mb-3">🤝</div>
              <h3 className="text-xl font-bold text-primary mb-2">Hỗ Trợ</h3>
              <p className="text-gray-700 text-sm">
                Đồng hành với cộng đồng để thực hiện các thay đổi bền vững.
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-6">
              <div className="text-4xl mb-3">🌍</div>
              <h3 className="text-xl font-bold text-primary mb-2">Tác Động</h3>
              <p className="text-gray-700 text-sm">
                Tạo ra sự thay đổi tích cực cho môi trường và hành tinh của chúng ta.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingChatButton />
    </div>
  )
}
